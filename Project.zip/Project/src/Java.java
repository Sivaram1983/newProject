
import java.util.HashMap;
import java.util.Map;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

//import com.sun.javafx.collections.MappingChange.Map;


public class Java {


    public static void main(String[] args) throws InterruptedException {
        
    	
    	
    	System.setProperty("webdriver.chrome.driver", "C://Users//sivar//Downloads//chromedriver_win32//chromedriver.exe");           
    	WebDriver driver = new ChromeDriver(); 

    	  driver.get("https://github.com/");    
    	
    	  Thread.sleep(2000); 
    	  
    	  WebElement username=driver.findElement(By.name("q"));
    	  
    	  username.sendKeys("react");
    	  
    	  Thread.sleep(2000);
    	  
    	  username.sendKeys(Keys.ENTER);
    	 
    	  Thread.sleep(2000);
    	  
    	  WebElement adsearch=driver.findElement(By.linkText("Advanced search"));
    	  adsearch.click();
    	  Thread.sleep(3000);
    	 
    	  WebElement searchstar=driver.findElement(By.id("search_stars"));
    	  searchstar.sendKeys(">45");
    	  Thread.sleep(3000);
    	  
    	 	 Select dropdown = new Select(driver.findElement(By.id("search_language")));
        	 dropdown.selectByVisibleText("JavaScript");
        	 Thread.sleep(3000);
    	
    	  WebElement search_followers1=driver.findElement(By.id("search_followers"));
    	  search_followers1.sendKeys(">50");
    	  Thread.sleep(3000);
    	  
    	  Select dropdown1 = new Select(driver.findElement(By.id("search_license")));
      	  dropdown1.selectByVisibleText("Boost Software License 1.0");
      	 Thread.sleep(3000);
    	 
      	driver.findElement(By.xpath("//*[@id=\"search_form\"]/div[2]/div/div/button")).click(); 
   	  Thread.sleep(3000);
    
    List<WebElement> result5 = driver.findElements(By.xpath(" //*[@id=\"js-pjax-container\"]/div/div[3]/div/ul/li/div[2]/div[1]/a"));
    int count5 =result5.size();
   
    
    WebElement something =driver.findElement(By.xpath(" //*[@id=\"js-pjax-container\"]/div/div[3]/div/ul/li/div[2]/div[1]/a"));
    String any = something.getText();
    
    String expectedName = "mvoloskov/decider";
   
    System.out.println("count----------->" +count5);
    System.out.println("Text ----------->" +any);
    
    if (count5 == 1){
        System.out.println("Count validation Passed");
    } else {
        System.out.println("Count validation Failed");
    }
    
    for (WebElement webElement : result5) {
        String name = webElement.getText();
        String name1 = webElement.getTagName();
       // String count = webElement.;
        System.out.println("Name " +name);
        System.out.println("Tagname " +name1);
        System.out.println(webElement.getText() + " ********** " + webElement.getAttribute("href"));
        
        if (name.contentEquals(expectedName)){
            System.out.println("mvoloskov/decider   -- Name validation Passed");
        } else {
            System.out.println("mvoloskov/decider   -- Name validation Failed");
        }
    }
    
    
    something.click();
    Thread.sleep(3000);
    
    WebElement something2 =driver.findElement(By.xpath("//*[@id=\"readme\"]"));
    String any2 = something2.getText();
    
    System.out.println("Complete Text  =  " +any2);
    String[] token = any2.split(" ");  
   
    /*
    for(int i=0; i<=300; i++)
    {
    	if(!(token[i].isEmpty())) {
			// report failure
    		System.out.print(i+"th Word  = "+token[i] + '\n');
		}
        
    }
    
    */
    
    HashMap<Integer,String> gfg = new HashMap<Integer,String>();
    int count=1;
    for(int i=0; i<token.length ;i++) {
    	
    	gfg.put(count, token[i] );
    	count++;
    }
    
    int j=1;
    	for (Map.Entry<Integer,String> entry : gfg.entrySet())
    		if(!(entry.getValue().isEmpty()) && !(entry.getValue() ==" ") && !(entry.getValue() =="") && !(entry.getValue() =="  ") && !(entry.getValue() ==null)) {
    			if(j<301) {
    			
                System.out.println( "******" +j+"Word or character  " + ", Value = " + entry.getValue());
        j++;
    			}
    			
        
    		}
    
   
    
    Thread.sleep(3000);
    
    driver.close();
    
    
		

       
    }

	
	
    
	
	

}



